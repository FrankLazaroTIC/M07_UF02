<!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Update</title>
    </head>
  <body>
    <h1><strong>Editar usuari</strong></h1>
        <form action="{{ route('estud.update', ['id' => $estud->id]) }}" method="POST">
            @method('PUT')
            @csrf
            <div>
                <label>Nom</label><br>
                <input type="text" name="nom" value={{$estud['nom']}}>
            </div>
            <div>
                <label>Cognom</label><br>
                <input type="text" name="cognoms" value={{$estud['cognoms']}}>
            </div>
            <div>
                <label>Contrasenya</label><br>
                <input type="password" name="contrassenya" value={{$estud['contrassenya']}} >
            </div>
            <div>
                <label>Email</label><br>
                <input type="email" name="email" value={{$estud['email']}}>
            </div>
            <div>
            <label>Rol</label><br>
                    <select name="rol" value={{$estud['rol']}}>
                        <option value="estudiant" {{ $estud['rol'] === 'estudiant' ? 'selected' : '' }}>Estudiant</option>
                        <option value="professor" {{ $estud['rol'] === 'professor' ? 'selected' : '' }}>Professor</option>
                        <option value="centre" {{ $estud['rol'] === 'centre' ? 'selected' : '' }}>Centre</option>
                    </select>
            </div>
            <div>
                <label>Active</label><br>
                <input type="checkbox" name="actiu" value={{$estud->actiu}}>
            </div>
            <input type="submit" value="Submit" name="Enviar">
        </form>
  </body>
</html>