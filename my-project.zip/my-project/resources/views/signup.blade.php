<!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Sing Up</title>
    </head>
  <body>
    <h1><strong>Crear un usuari</strong></h1>
        <form action="/login" method="POST">
            <div>
                <label>Numero</label><br>
                <input type="email" id="email"><br>
            </div>
            <div>
                <label>Nom</label><br>
                <input type="text" name="name">
            </div>
            <div>
                <label>Cognom</label><br>
                <input type="text" name="surname">
            </div>
            <div>
                <label>Contrasenya</label><br>
                <input type="password" name="password">
            </div>
            <div>
                <label>Email</label><br>
                <input type="email" name="email">
            </div>
            <div>
                <label>Rol</label><br>
                <select name="rol">
                    <option value="Professor">Professor</option>
                    <option value="Alumne">Alumne</option>
                </select>
            </div>
            <div>
                <label>Active</label><br>
                <input type="checkbox" name="active">
            </div>
            <input type="submit" value="Submit" name="Enviar">
        </form>
        <a href="/login">Iniciar sessio</a>
  </body>
</html>