<h1>Benvingut professor.</h1>
<h2>Llista estudiants</h2>
@if(count($llistaEstud) > 0)
<table>
    <tr>
        <th>Id</th>
        <th>Nom</th>
        <th>Cognom</th>
    </tr>
    @foreach($llistaEstud as $estud)
    <tr>
        <td>{{$estud['id']}} </td>
        <td>{{$estud['nom']}} </td>
        <td>{{$estud['cognoms']}} </td>
        <td>{{$estud['email']}} </td>
        <td><a href="{{'/estud/edit/'.$estud['id']}}">Editar</a></td>
        <td>
            <form action="{{ url('estud/'.$estud['id'])}}" method="post">
                @method("delete")
                @csrf
                <input type="submit" value="delete">
            </form>
        </td>
    </tr>
    @endforeach
</table>
@endif