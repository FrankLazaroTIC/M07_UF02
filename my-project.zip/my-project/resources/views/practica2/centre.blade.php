<h1>Benvingut administrador</h1>
<h2>Llista de professors</h2>
@if(count($llistaProf) > 0)
<table>
    <tr>
        <th>Id</th>
        <th>Nom</th>
        <th>Cognom</th>
    </tr>
    @foreach($llistaProf as $prof)
    <tr>
        <td>{{$prof['id']}} </td>
        <td>{{$prof['nom']}} </td>
        <td>{{$prof['cognoms']}} </td>
        <td>{{$prof['email']}} </td>
        <td><a href="{{'/prof/edit/'.$prof['id']}}">Editar</a></td>
        <td>
            <form action="{{ url('prof/'.$prof['id'])}}" method="post">
                @method("delete")
                @csrf
                <input type="submit" value="delete">
            </form>
        </td>
    </tr>
    @endforeach
</table>
@endif