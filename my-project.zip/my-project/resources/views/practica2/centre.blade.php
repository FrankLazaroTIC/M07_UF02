<h1>Benvingut administrador. El teu email és {{$email}}</h1>
<h2>Llista de professors</h2>
<table>
    <tr><th>id</th><th>nom</th><th>email</th><th>curs</th></tr>
    <tr><td>1</td><td>Oriol</td><td>oriol@example.com</td><td>1</td></tr>
    <tr><td>2</td><td>Joana</td><td>joana@example.com</td><td>1</td></tr>
    <tr><td>3</td><td>Carla</td><td>carla@example.com</td><td>2</td></tr>
</table>
    
    