<!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Update</title>
    </head>
  <body>
    <h1><strong>Editar usuari</strong></h1>
        <form action="{{ route('prof.update', ['id' => $prof->id]) }}" method="POST">
            @method('PUT')
            @csrf
            <div>
                <label>Nom</label><br>
                <input type="text" name="nom" value={{$prof['nom']}}>
            </div>
            <div>
                <label>Cognom</label><br>
                <input type="text" name="cognoms" value={{$prof['cognoms']}}>
            </div>
            <div>
                <label>Contrasenya</label><br>
                <input type="password" name="contrassenya" value={{$prof['contrassenya']}} >
            </div>
            <div>
                <label>Email</label><br>
                <input type="email" name="email" value={{$prof['email']}}>
            </div>
            <div>
            <label>Rol</label><br>
                    <select name="rol" value={{$prof['rol']}}>
                        <option value="estudiant" {{ $prof['rol'] === 'estudiant' ? 'selected' : '' }}>Estudiant</option>
                        <option value="professor" {{ $prof['rol'] === 'professor' ? 'selected' : '' }}>Professor</option>
                        <option value="centre" {{ $prof['rol'] === 'centre' ? 'selected' : '' }}>Centre</option>
                    </select>
            </div>
            <div>
                <label>Active</label><br>
                <input type="checkbox" name="actiu" value={{$prof->actiu}}>
            </div>
            <input type="submit" value="Submit" name="Enviar">
        </form>
  </body>
</html>