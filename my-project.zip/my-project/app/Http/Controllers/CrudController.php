<?php

namespace App\Http\Controllers;

use App\Models\Usuari;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class CrudController extends Controller
{
    function formEdit($id){
        $prof = Usuari::find($id);
        return View("update")->with("prof", $prof);
    }

    function formEditEst($id){
        $estud = Usuari::find($id);
        return View("updateEstud")->with("estud", $estud);
    }

    function updateProf($id){
        //Trobem el usuari amb el mateix id
        $prof = Usuari::find($id);

        //Fiquem les dades al formulari
        $prof->nom = request('nom');
        $prof->cognoms = request('cognoms');
        $prof->email = request('email');
        $prof->contrassenya = request('contrassenya');
        $prof->rol = request('rol');
        $prof->save();

        //Guardem l'usuari
        $prof->save();

        //Pasem a la vista la variable amb la llista de professors actualitzada
        $llistaProf= Usuari::where('rol','professor')->get();
        return view('practica2.centre', ['llistaProf' => $llistaProf]); 
    }

    function updateEstud($id){
        //Trobem el usuari amb el mateix id
        $estud = Usuari::find($id);

        //Fiquem les dades al formulari
        $estud->nom = request('nom');
        $estud->cognoms = request('cognoms');
        $estud->email = request('email');
        $estud->contrassenya = request('contrassenya');
        $estud->rol = request('rol');
        $estud->save();

        //Guardem l'usuari
        $estud->save();

        //Pasem a la vista la variable amb la llista de estudiants actualitzada
        $llistaEstud= Usuari::where('rol','estudiant')->get();
        return view('practica2.professor', ['llistaEstud' => $llistaEstud]); 
    }

    function deleteProf($id){
        Usuari::destroy($id);

        //Pasem a la vista la variable amb la llista de professors actualitzada
        $llistaProf = Usuari::where('rol', 'professor')->get();
        return view('practica2.centre', ['llistaProf' => $llistaProf]);
    }

    function deleteEstud($id){
        Usuari::destroy($id);

        //Pasem a la vista la variable amb la llista de estudiants actualitzada
        $llistaEstud = Usuari::where('rol', 'estudiant')->get();
        return view('practica2.centre', ['llistaEstud' => $llistaEstud]);
    }
}
