<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Usuari;
use Illuminate\Support\Facades\Auth;

class LoginController extends Controller
{
    
public function register(Request $request){
        Usuari::create($request->all());

        return "La inserció es correcte. <a href='/login'>Iniciar sessió usuari</a>";
    }

public function login(Request $request){  
        $email = Usuari::where('email', $request->input('email'))->first();
        $password = Usuari::where('contrassenya', $request->input('contrassenya'))->first();
        $emailMostra = $request->input('email');

        if ($email && $password) {
            if ($email->rol == 'estudiant') {
                return view('practica2.alumne')->with('email', $emailMostra);
            } elseif ($email->rol == 'centre') {
                $llistaProf= Usuari::where('rol','professor')->get();
                return view('practica2.centre')->with('llistaProf', $llistaProf);
            } elseif ($email->rol == 'professor') {
                $llistaEstud= Usuari::where('rol','estudiant')->get();
                return view('practica2.professor')->with('llistaEstud', $llistaEstud);
            } 
        } else {
                return "Contrassenya incorrecta . <a href='/login'>Iniciar sessió usuari</a>";
            }
    }
}