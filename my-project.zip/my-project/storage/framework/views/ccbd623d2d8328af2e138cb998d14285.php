<!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Update</title>
    </head>
  <body>
    <h1><strong>Editar usuari</strong></h1>
        <form action="<?php echo e(route('estud.update', ['id' => $estud->id])); ?>" method="POST">
            <?php echo method_field('PUT'); ?>
            <?php echo csrf_field(); ?>
            <div>
                <label>Nom</label><br>
                <input type="text" name="nom" value=<?php echo e($estud['nom']); ?>>
            </div>
            <div>
                <label>Cognom</label><br>
                <input type="text" name="cognoms" value=<?php echo e($estud['cognoms']); ?>>
            </div>
            <div>
                <label>Contrasenya</label><br>
                <input type="password" name="contrassenya" value=<?php echo e($estud['contrassenya']); ?> >
            </div>
            <div>
                <label>Email</label><br>
                <input type="email" name="email" value=<?php echo e($estud['email']); ?>>
            </div>
            <div>
            <label>Rol</label><br>
                    <select name="rol" value=<?php echo e($estud['rol']); ?>>
                        <option value="estudiant" <?php echo e($estud['rol'] === 'estudiant' ? 'selected' : ''); ?>>Estudiant</option>
                        <option value="professor" <?php echo e($estud['rol'] === 'professor' ? 'selected' : ''); ?>>Professor</option>
                        <option value="centre" <?php echo e($estud['rol'] === 'centre' ? 'selected' : ''); ?>>Centre</option>
                    </select>
            </div>
            <div>
                <label>Active</label><br>
                <input type="checkbox" name="actiu" value=<?php echo e($estud->actiu); ?>>
            </div>
            <input type="submit" value="Submit" name="Enviar">
        </form>
  </body>
</html><?php /**PATH /app/resources/views/updateEstud.blade.php ENDPATH**/ ?>