<h1>Benvingut professor.</h1>
<h2>Llista estudiants</h2>
<?php if(count($llistaEstud) > 0): ?>
<table>
    <tr>
        <th>Id</th>
        <th>Nom</th>
        <th>Cognom</th>
    </tr>
    <?php $__currentLoopData = $llistaEstud; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $estud): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($estud['id']); ?> </td>
        <td><?php echo e($estud['nom']); ?> </td>
        <td><?php echo e($estud['cognoms']); ?> </td>
        <td><?php echo e($estud['email']); ?> </td>
        <td><a href="<?php echo e('/estud/edit/'.$estud['id']); ?>">Editar</a></td>
        <td>
            <form action="<?php echo e(url('estud/'.$estud['id'])); ?>" method="post">
                <?php echo method_field("delete"); ?>
                <?php echo csrf_field(); ?>
                <input type="submit" value="delete">
            </form>
        </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<?php endif; ?><?php /**PATH /app/resources/views/practica2/professor.blade.php ENDPATH**/ ?>