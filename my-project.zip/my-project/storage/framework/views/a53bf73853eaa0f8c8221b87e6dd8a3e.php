<h1>Benvingut administrador</h1>
<h2>Llista de professors</h2>
<?php if(count($llistaProf) > 0): ?>
<table>
    <tr>
        <th>Id</th>
        <th>Nom</th>
        <th>Cognom</th>
    </tr>
    <?php $__currentLoopData = $llistaProf; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prof): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($prof['id']); ?> </td>
        <td><?php echo e($prof['nom']); ?> </td>
        <td><?php echo e($prof['cognoms']); ?> </td>
        <td><?php echo e($prof['email']); ?> </td>
        <td><a href="<?php echo e('/prof/edit/'.$prof['id']); ?>">Editar</a></td>
        <td>
            <form action="<?php echo e(url('prof/'.$prof['id'])); ?>" method="post">
                <?php echo method_field("delete"); ?>
                <?php echo csrf_field(); ?>
                <input type="submit" value="delete">
            </form>
        </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<?php endif; ?><?php /**PATH /app/resources/views/practica2/centre.blade.php ENDPATH**/ ?>